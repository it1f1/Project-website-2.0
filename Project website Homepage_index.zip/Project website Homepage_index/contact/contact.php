<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dummy</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
        *{
            margin: 0;
            padding: 0;
        }
        h1, h2, h3, h4, h5{
            margin: 0;
            padding: 0;
        }
        body{
            background-color: grey;
            font-family: arial, helvetica, verdana, sans-serif;
            font-size: 12px;
        }
        .mainContainerWrapper{
            width: 100%;
            background-color: red;
            float: left;
        }
        .mainContainer{
            margin: 0 auto;
            background-color: yellow;
            width: 1300px;
            height: auto;
        }
        header{
            width: 1300px;
            height: 300px;
            float: left;
            background-color: #ffffff;
        }
        .headerLogo{
            width: 1300px;
            height: 110px;
            float: left;
            background-color: #fff;
            padding-left: 600px;
            padding-top: 10px;
        }
        .headerText{
            width: 1300px;
            height: 100px;
            float: left;
            background-color: #ffffff;
        }
        header h1{
            padding-top: 10px;
            color: #003399;
            text-align: center;
        }
        header h2{
            color: #003399;
            font-size: 16px;
            text-align: center;
        }
        .menu{
            background-color: #fff;
            float: left;
            width: 1300px;
            height: 90px;
            text-align: center;
        }
        nav.menu ul{
            list-style-type: none;
        }
        nav.menu li{
            padding-left: 20px;
            padding-top: 20px;
            display:inline-block;
            margin-right: 40px;
        }
        nav.menu li a{
            text-decoration: none;
            color: black;
            font-size: 22px;
        }
        nav.menu li a:hover{
            border-bottom: 3px solid #003399;
        }
        .mainContent{
            float:left;
            background-color: yellow;
            width: 1300px;
            /*
            Gave it a static height right now, change it to auto when you've put shit in it.
             */
            height: 600px;
        }
        footer{
            float: left;
            width: 1300px;
            height: 50px;
            background-color: pink;
        }
        .footerLeft{
            float: left;
            width: 650px;
            height: 50px;
        }
        .footerLeft p{
            margin-top: 12px;
            margin-left: 10px;
            font-size: 16px;
        }
        .footerRight{
            float: left;
            width: 650px;
            height: 50px;
        }
        .footerIcons{
            float: right;
            margin-top: 7.5px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="mainContainerWrapper">
        <div class="mainContainer">
            <header>
                <div class="headerLogo">
                    <img src="images/logo.png" alt="logo" width="100" height="100">
                </div>
                <div class="headerText">
                    <h1>Emmen Tech University</h1>
                    <h2>For higher learning</h2>
                </div>
                <nav class="menu">
                    <div clas="menuWrapper">
                        <ul>
                            <li> <a href="#"> Home </a> </li>
                            <li> <a href="#"> About us </a> </li>
                            <li> <a href="#"> Programs </a> </li>
                            <li> <a href="#"> Contact </a> </li>
                            <select name="Language">
                                <option value="English">EN</option>
                                <option value="Nederlands">NL</option>
                            </select>
                        </ul>
                    </div>
                </nav>
            </header>
            <div class="mainContent">
            </div>
            <footer>
                <div class="footerLeft">
                    <p>&copy; Emmen Tech</p>
                </div>
                <div class="footerRight">
                    <div class="footerIcons">
                        <img src="images/facebookIcon.png" alt="FacebookIcon">
                        <img src="images/twitterIcon.png" alt="TwitterIcon">
                    </div>
            </footer>
        </div>
    </div>
</body>
</html>