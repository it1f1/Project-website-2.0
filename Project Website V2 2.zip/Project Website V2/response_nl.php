<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/contact.css" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="mainContainerWrapper">
        <div class="mainContainer">
            <header>
                <div class="headerLogo">
                    <img src="images/logo.png" alt="logo" width="100" height="100">
                </div>
                <div class="headerText">
                    <h1>Emmen Tech University</h1>
                    <h2>For higher learning</h2>
                </div>
                <nav class="menu">
                    <div class="menuWrapper">
                        <ul>
                            <li> <a href="index_nl.html"> Home </a> </li>
                            <li> <a href="aboutus_nl.html"> Over ons </a> </li>
                            <li> <a href="programs_nl.html"> Programma's </a> </li>
                            <li> <a href="contact_nl.php"> Contact </a> </li>
                            <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                                <option value="#">Language</option>
                                <option value="response_en.php">EN</option>
                                <option value="response_nl.php">NL</option>
                            </select>
                        </ul>
                    </div>
                </nav>
            </header>
            <div class="mainContent">
               <div class="message">
                   <p>Dankuwel voor je bericht!</p>
                    <p>We zullen je z.s.m een bericht terug sturen.</p>
                </div>
            </div>
            <footer>
                <div class="footerLeft">
                    <p>&copy; Emmen Tech</p>
                </div>
                <div class="footerRight">
                    <div class="footerIcons">
                        <img src="images/facebookIcon.png" alt="FacebookIcon">
                        <img src="images/twitterIcon.png" alt="TwitterIcon">
                    </div>
                </div>    
            </footer>
        </div>    
    </div>
</body>
</html>
