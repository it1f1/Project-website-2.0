<?php
    include("form_en.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/contact.css" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="mainContainerWrapper">
        <div class="mainContainer">
            <header>
                <div class="headerLogo">
                    <img src="images/logo.png" alt="logo" width="100" height="100">
                </div>
                <div class="headerText">
                    <h1>Emmen Tech University</h1>
                    <h2>For higher learning</h2>
                </div>
                <nav class="menu">
                    <div class="menuWrapper">
                        <ul>
                            <li> <a href="index_en.html"> Home </a> </li>
                            <li> <a href="aboutus_en.html"> About us </a> </li>
                            <li> <a href="programs_en.html"> Programs </a> </li>
                            <li> <a href="contact_en.php"> Contact </a> </li>
                            <select onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                                <option value="#">Language</option>
                                <option value="contact_en.php">EN</option>
                                <option value="contact_nl.php">NL</option>
                            </select>
                        </ul>
                    </div>
                </nav>
            </header>
            <div class="mainContent">
               
                <div class="contact">
                    <h1>Contact us</h1>
                    <img src="images/contact2.jpg" alt="contact us picture">
                    <p>Send us your questions via post or email.</p>
                </div>

                <div class="Contact">
                    <div class="addressBox">
                        <ul>
                          <li class="list">NHL Stenden University of Applied Sciences</li>
                          <li class="list">Van Schaikweg 94</li>
                          <li class="list">7811 KL Emmen</li>
                          <li class="list">receptie.emmen@stenden.com</li>
                          <li class="list">+31 (0)591 853 100</li>
                        </ul>

                    </div>

                    <div class="Form">

                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">

                            <div class="form-details">

                                <input type="text" name="fname" placeholder="Name *" size="25" required>
                                <input type="email" name="email" placeholder="Email *" size="25" required><br/>
                                <span class="error position-email-error">
                                        <?php if(isset($emailError))
                                        echo $emailError;?>
                                </span>
             

                                <input type="text" name="address" placeholder="Address *" size="59" required>

                                <input type="tel" name="phone-number" placeholder="Tel: eg:0234 *" size="59" required><br/>
                                <span class="error position-tel-error">
                                    <?php if(isset($telError))
                                    echo $telError;?>
                                </span> 



                                <textarea rows="8" cols="64" placeholder="Message *" name="message" required></textarea>

                                <input type="submit" name="submit" value="Send">
                                
                            </div>

                        </form>

                    </div>

                </div>
                <div class="mapouter"><div class="gmap_canvas"><iframe width="1300" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=Van%20Schaikweg%2094%207811%20KL%20Emmen&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.emojilib.com"></a></div></div>

            </div>
            <footer>
                <div class="footerLeft">
                    <p>&copy; Emmen Tech</p>
                </div>
                <div class="footerRight">
                    <div class="footerIcons">
                        <img src="images/facebookIcon.png" alt="FacebookIcon">
                        <img src="images/twitterIcon.png" alt="TwitterIcon">
                    </div>
                </div>    
            </footer>
        </div>    
    </div>
</body>
</html>






