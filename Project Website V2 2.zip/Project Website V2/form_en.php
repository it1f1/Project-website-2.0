<?php

    if (isset($_POST['submit']))
    {
            $email  = $_POST['email'];//get the mail
            $phone = $_POST['phone-number'];//get the tel phone number
            $fname = $_POST['fname'];
            $address = $_POST['address'];
            $message = $_POST['message'];

            $phone_len = strlen($phone);//get the length of the phone number

            // Remove all illegal characters from email
            $email = filter_var($email, FILTER_SANITIZE_EMAIL);

            if (!filter_var($email,FILTER_VALIDATE_EMAIL)) //to check if it is not in an email format
            {

                $emailError= "Please enter an appropriate mail";

            }   

            if ( ($phone_len > 13) || (!is_numeric($phone)) )//to check if the phone is more than more and not in numbers
            {

                $telError = "Enter an appropriate phone number";
            }

            //to check if its  valid both phone and email
            else if ((!$phone_len > 13) ||(is_numeric($phone)) && (filter_var($email, FILTER_VALIDATE_EMAIL)) )
            {

               header("Location: http://localhost/Project Website/response_en.php");

            }   
             else;//do nothing   

    }
?>








